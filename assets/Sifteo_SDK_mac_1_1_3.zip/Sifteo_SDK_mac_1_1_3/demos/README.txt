Welcome to Demo Zone.

Firstly, ensure that you have not opened the Do Not Open demo.

Each of these demos is configured to run in development mode. To run them:
 * open up the .sln file in MonoDevelop for the demo of your choice, build it and run/debug
 * the demo should be idle, waiting for Siftdev to connect to it
 * open Siftdev, log in, and select 'Load Apps' from the Developer menu
 * load the folder this file is in, containing all the demos - they should now show up in Siftdev
 * select the demo you'd like to run, install if necessary, then hit play
 * Siftdev will connect to the demo and start running it - that's it!
 
Lastly, please double check that you have not opened the Do Not Open demo.

Enjoy!
